<h1>VOID47 Chat Application</h1>

This is a real-time chat application written in pure PHP/MYSQL.

